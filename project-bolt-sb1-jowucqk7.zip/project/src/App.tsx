import React, { useEffect } from 'react';
import { Dice1 as Dice, Tent, Phone, Mail, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';
import AOS from 'aos';
import 'aos/dist/aos.css';

function App() {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true,
      easing: 'ease-out-cubic'
    });
  }, []);

  const games = [
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/Subsoccer.webp", name: "Subsoccer" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/8b02949c01afc150238c21710a1ee5f494b63a2e/Billiards%20Pool%20Table.webp", name: "Billiard Table" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/Foosball.webp", name: "Foosball" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/8b02949c01afc150238c21710a1ee5f494b63a2e/Air%20Hockey.webp", name: "Air Hockey" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/PlayStation.webp", name: "PlayStation" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/Xbox.webp", name: "Xbox" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/8b02949c01afc150238c21710a1ee5f494b63a2e/Board%20Games.webp", name: "Board Games" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/Classic-Four-in-a-row.webp", name: "Four in a row" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/CornHole.webp", name: "Corn Hole" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/Giant-Four-in-a-row.webp", name: "Four in a row" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/JBL-Speaker.webp", name: "JBL Speaker" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/Jenga-Giant.webp", name: "Jenga Giant" },
    { src: "https://raw.githubusercontent.com/makinsauto/imperialiti_pictures/refs/heads/main/Ping-Pong-table.webp", name: "Ping Pong table" }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Fixed Navigation Container */}
      <div className="fixed top-0 left-0 right-0 z-50 px-4 py-4">
        <nav className="mx-auto max-w-7xl bg-gray-900/80 backdrop-blur-sm rounded-full border border-gray-700 shadow-lg">
          <div className="px-8 py-3 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Dice className="h-8 w-8 text-purple-400" />
              <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 text-transparent bg-clip-text">
                IMPERIALITI
              </span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#games" className="text-gray-300 hover:text-purple-400 transition-colors">Games</a>
              <a href="#features" className="text-gray-300 hover:text-purple-400 transition-colors">About</a>
              <a href="#contact" className="text-gray-300 hover:text-purple-400 transition-colors">Contact</a>
            </div>
          </div>
        </nav>
      </div>

      {/* Hero Section with sophisticated background */}
      <header className="pt-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900 to-purple-900">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS1vcGFjaXR5PSIwLjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20"></div>
        </div>
        <div className="container mx-auto px-6 py-24 text-center relative">
          <div data-aos="fade-up">
            <h1 className="text-5xl font-bold mb-6 text-white">Make Your Event Unforgettable</h1>
            <p className="text-xl mb-8 text-gray-300">Premium indoor and outdoor game rentals for any occasion</p>
            <a 
              href="#games"
              className="inline-block bg-blue-500 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-600 transition-all transform hover:scale-105"
            >
              Browse Games
            </a>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 bg-gray-800" id="features">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
            <div className="text-center" data-aos="fade-up" data-aos-delay="0">
              <div className="bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transform hover:scale-110 transition-transform">
                <Dice className="h-8 w-8 text-blue-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Indoor Games</h3>
              <p className="text-gray-300">Board games, arcade machines, and interactive entertainment</p>
            </div>
            <div className="text-center" data-aos="fade-up" data-aos-delay="100">
              <div className="bg-purple-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transform hover:scale-110 transition-transform">
                <Tent className="h-8 w-8 text-purple-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Outdoor Games</h3>
              <p className="text-gray-300">Giant versions of classic games and sports equipment</p>
            </div>
            <div className="text-center" data-aos="fade-up" data-aos-delay="200">
              <div className="bg-green-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transform hover:scale-110 transition-transform">
                <MapPin className="h-8 w-8 text-green-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Local Delivery</h3>
              <p className="text-gray-300">Setup and collection service available</p>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-gray-900" id="games">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-white" data-aos="fade-up">Our Game Collection</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {games.map((game, index) => (
              <div 
                key={index} 
                className="relative group aspect-w-16 aspect-h-9" 
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <img 
                  src={game.src} 
                  alt={game.name} 
                  className="rounded-lg shadow-md transition-all duration-300 object-cover w-full h-64"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-end justify-center pb-6">
                  <h3 className="text-white text-xl font-semibold">{game.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-gray-800 py-20" id="contact">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-white" data-aos="fade-up">Get In Touch</h2>
          <div className="flex flex-col md:flex-row justify-center space-y-6 md:space-y-0 md:space-x-12" data-aos="fade-up" data-aos-delay="100">
            <div className="flex items-center space-x-4 text-gray-300">
              <Phone className="h-6 w-6 text-blue-400" />
              <span>(905) 517-8278</span>
            </div>
            <div className="flex items-center space-x-4 text-gray-300">
              <Mail className="h-6 w-6 text-blue-400" />
              <span>imperialitirentals@gmail.com</span>
            </div>
            <div className="flex items-center space-x-4 text-gray-300">
              <MapPin className="h-6 w-6 text-blue-400" />
              <span>Ontario, Canada</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-6 md:mb-0">
              <Dice className="h-8 w-8" />
              <span className="text-xl font-bold">IMPERIALITI</span>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="hover:text-blue-400 transition-colors"><Instagram className="h-6 w-6" /></a>
              <a href="#" className="hover:text-blue-400 transition-colors"><Facebook className="h-6 w-6" /></a>
              <a href="#" className="hover:text-blue-400 transition-colors"><Twitter className="h-6 w-6" /></a>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-400">
            <p>&copy; 2024 IMPERIALITI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;