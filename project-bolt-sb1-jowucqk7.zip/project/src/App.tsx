import React from 'react';
import { Dice1 as Dice, Tent, Phone, Mail, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      {/* Fixed Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-blue-900 to-purple-900 text-white shadow-lg">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Dice className="h-8 w-8" />
            <span className="text-xl font-bold">IMPERIALITI</span>
          </div>
          <div className="hidden md:flex space-x-8">
            <a href="#games" className="hover:text-blue-300">Games</a>
            <a href="#about" className="hover:text-blue-300">About</a>
            <a href="#contact" className="hover:text-blue-300">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section with padding to account for fixed nav */}
      <header className="pt-20 bg-gradient-to-r from-blue-900 to-purple-900 text-white">
        <div className="container mx-auto px-6 py-24 text-center">
          <h1 className="text-5xl font-bold mb-6">Make Your Event Unforgettable</h1>
          <p className="text-xl mb-8">Premium indoor and outdoor game rentals for any occasion</p>
          <button className="bg-blue-500 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-600 transition-colors">
            Browse Games
          </button>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Dice className="h-8 w-8 text-blue-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Indoor Games</h3>
              <p className="text-gray-300">Board games, arcade machines, and interactive entertainment</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Tent className="h-8 w-8 text-purple-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Outdoor Games</h3>
              <p className="text-gray-300">Giant versions of classic games and sports equipment</p>
            </div>
            <div className="text-center">
              <div className="bg-green-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-green-300" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">Local Delivery</h3>
              <p className="text-gray-300">Setup and collection service available</p>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-white">Popular Games</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <img 
              src="https://images.unsplash.com/photo-1606503153255-59d5e417e3f3?auto=format&fit=crop&w=800&q=80" 
              alt="Board games" 
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300"
            />
            <img 
              src="https://images.unsplash.com/photo-1585504198199-20277593b94f?auto=format&fit=crop&w=800&q=80" 
              alt="Outdoor games" 
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300"
            />
            <img 
              src="https://images.unsplash.com/photo-1611996575749-79a3a250f948?auto=format&fit=crop&w=800&q=80" 
              alt="Party games" 
              className="rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300"
            />
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-gray-800 py-20" id="contact">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-white">Get In Touch</h2>
          <div className="flex flex-col md:flex-row justify-center space-y-6 md:space-y-0 md:space-x-12">
            <div className="flex items-center space-x-4 text-gray-300">
              <Phone className="h-6 w-6 text-blue-400" />
              <span>(905) 517-8278</span>
            </div>
            <div className="flex items-center space-x-4 text-gray-300">
              <Mail className="h-6 w-6 text-blue-400" />
              <span>imperialitirentals@gmail.com</span>
            </div>
            <div className="flex items-center space-x-4 text-gray-300">
              <MapPin className="h-6 w-6 text-blue-400" />
              <span>Ontario, Canada</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-6 md:mb-0">
              <Dice className="h-8 w-8" />
              <span className="text-xl font-bold">IMPERIALITI</span>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="hover:text-blue-400"><Instagram className="h-6 w-6" /></a>
              <a href="#" className="hover:text-blue-400"><Facebook className="h-6 w-6" /></a>
              <a href="#" className="hover:text-blue-400"><Twitter className="h-6 w-6" /></a>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-400">
            <p>&copy; 2024 IMPERIALITI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;